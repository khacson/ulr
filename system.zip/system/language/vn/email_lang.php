<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['date_year'] = 'Year test';
